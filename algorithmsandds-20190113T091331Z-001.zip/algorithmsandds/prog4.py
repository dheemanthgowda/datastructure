#Implement a transfer function and two temporary stacks,
# to replace the contents of a given stack S with those same elements, but in reverse order.
import stackmaster
S = stackmaster.limitedStack()
T1 = stackmaster.limitedStack()
T2 = stackmaster.limitedStack()
for r in range(int(input("Enter length of stack:"))):
	S.stackpush(input("enter elements: "))
print("STACK S")
S.displaystack()
def transfer(S):
	for ch in range(S.stacklength()):
		T1.stackpush(S.stackpeek())
		S.stackpop()

	for ch in range(T1.stacklength()):
	#print(T1.stackpeek())
		T2.stackpush(T1.stackpeek())
		T1.stackpop()
	for ch in range(T2.stacklength()):
		S.stackpush(T2.stackpeek())
		T2.stackpop()
	return
transfer(S)
print("STACK S after transfer function")
S.displaystack()

