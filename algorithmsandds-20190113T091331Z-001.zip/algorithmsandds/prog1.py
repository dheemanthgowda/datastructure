#Implement a function withn signature transfer(S,T) that transfers all elements from Stack S onto Stack T, 
#so that that elements that starts at the top of S is the first to be inserted into T, 
#and element at the bottom of S ends up at the top of T.


import stackmaster
S = stackmaster.limitedStack()
T = stackmaster.limitedStack()
r = int(input("enter length: "))
print("input stack S:")
for ch in range(r):
	ele = input()
	S.stackpush(ele)

def signaturetransfer(S,T):
	
	for ch in range(S.stacklength()):
		T.stackpush(S.stackpeek())
		S.stackpop()
signaturetransfer(S,T)
print("stack T")
T.displaystack()



