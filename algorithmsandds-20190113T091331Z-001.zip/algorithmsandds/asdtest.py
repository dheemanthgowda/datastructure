"""
3. Design an application to keep track of shares transaction. Customer can purchase and sell
shares. Customer should sell oldest shares in hand. At any point of time customer can’t have
shares of more than 5 companies. Information needed to store is company name, number of
shares and price of unit share. While selling customer tells price of share at that time.
Compute the total gain or loss.
"""
import queuemaster as q
class share:
	def __init__(self):
		self.data = q.flexiqueue()
		#self.d = {}
		self.count = 0
		self.front = 0

	def buy_shares(self,d):
		self.data.qenqueue(d)
		
		
		
		
		
	def sell_shares(self):
		
		
		share_info = self.data.qdequeue()
		print("share Information:    ",share_info)


		for key,values in share_info.items():
			shares = share_info.get(key,"NA")
		
		

		
		#print(type(shares))
		no_of_shares = shares[0]
		 
		#print(shares)
		unit_price = shares[1]
		#print(no_of_shares,unit_price)
		selling_price = int(input("enter current share price of each: "))
		
		selling = no_of_shares* selling_price
		purchase = no_of_shares* unit_price
		
		
		print("Selling price",selling)
		print("Cost price",purchase)
		self.profit_loss(selling,purchase)

	def profit_loss(self,selling,purchase):
		compute = selling - purchase
		if(compute < 0):
			print("loss of:",abs(compute))
		else:
			print("profit of:",compute)
		return
	def display(self):

		self.data.displayqueue()

customer = share()
customer.buy_shares({"company_1":[50,3]})
customer.buy_shares({"company_2":[70,4]})
customer.buy_shares({"company_3":[30,6]})


customer.buy_shares({"company_4":[10,2]})
customer.buy_shares({"company_5":[80,1]})
customer.buy_shares({"company_6":[80,1]})
customer.display()
customer.sell_shares()

customer.sell_shares()
customer.display()
