#Design a stack using a single queue as an instance variable, 
#and only constant additional local memory within the method bodies.

import queuemaster as q

class Stack:
	
	def __init__(self):
		self.data = q.flexiqueue()
	
	def isstackempty(self):
		return self.data.isqEmpty()
	
	
	
	def stacklength(self):
		return self.data.qlength()

	
	def stackpush(self,ele):
		c = []
		for ch in range(self.data.qlength()):
			k = self.data.qdequeue()
			c.append(k)

			#print(ch,k)
		#print('\n')	#print(ch)
		print(c)


		self.data.qenqueue(ele)

		for ch in c:
			self.data.qenqueue(ch)
			
			
		
			

	def stackpop(self):
		if not self.isstackempty():
			self.data.qdequeue()
			
			
	def displaystack(self):
		self.data.displayqueue()
		#print("s")

if __name__ == '__main__':
	s1 = Stack()
	s1.stackpush('a')
	s1.stackpush('b')
	s1.stackpush('c')
	s1.stackpush('d')
	s1.stackpush('e')
	s1.stackpush('f')
	s1.stackpush('g')
	s1.stackpop()
	s1.stackpop()

	#s1.stackpop()
	s1.displaystack()
