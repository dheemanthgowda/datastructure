class BST:
	class _TreeNode:
		def __init__(self,ele):
			self.data = ele
			self.left = None
			self.right = None
	def __init__(self):
		self.root = None
		self.count = 0
	def add_node(self,ele):
		current = parent = self.root
		