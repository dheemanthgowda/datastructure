##6.      Suppose you have three nonempty stacks R, S and T.
# Describe a sequence of operations that results in S storing all elements originally in T below of S’s original elements, 
#with both sets of those elements in their original configuration.
## For example, if R = [1,2,3], S = [4, 5] and T = [6, 7, 8, 9], the final configuration should have R = [1, 2, 3] and S = [6, 7, 8,  9, 4, 5].def transfer(S,T,R):
	new_len=S.stacklength()+T.stacklength()
	print(new_len)
	for ch in range(S.stacklength()):
		R.stackpush(S.stackpop())

	for ch in range(T.stacklength()):
		R.stackpush(T.stackpop())

	for item in range(new_len):
		S.stackpush(R.stackpop())

	print("Stack S: ")
	S.displaystack()

	print("Stack T: ")
	T.displaystack()

	print("Stack R: ")
	R.displaystack()


R=stackimplement.stack()#object of first stack
S=stackimplement.stack()#object of Second stack
T=stackimplement.stack()#object of third stack


n=int(input("enter the length of element in stack R:  "))
print("enter the contents of stack R:")
for ch in range(n):
	ele=input()
	R.stackpush(ele)#entering element in frst stack
R.displaystack()

p=int(input("enter the length of element in stack S:  "))
print("enter the contents of stack S:")
for ch in range(p):
	ele=input()
	S.stackpush(ele)#entering element in second stack
S.displaystack()

q=int(input("enter the length of element in stack T:  "))
print("enter the contents of stack T:")
for ch in range(q):
	ele=input()
	T.stackpush(ele)#entering element in third stack
T.displaystack()
transfer(S,T,R)
#print("Stack R:")
#R.displaystack()
