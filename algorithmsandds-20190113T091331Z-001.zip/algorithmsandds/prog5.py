##5.HTML generally allows optional attributes to be expressed as part of an opening tag. The general form used is <name attribute1 = “value1” attribute2 = “value2”>.
## Write function that checks whether tags or matched properly, even when an opening tag may include one or more attributes.

import stackmaster

def evalHTML(st):

	stk = stackmaster.limitedStack()	
	start = st.index('<')
	#print(start)
	while start != -1:
		end = st.index('>',start+1)
		#print(end)
		if end == -1:
			return False
		tok = st[start+1 : end]
		#print(tok)
		
		if not tok.startswith('/'):
			t = tok.split(" ")
			print(t)
			stk.stackpush(t[0])
		else:
			if stk.isstackempty():
			 	return False
			if tok[1:]!= stk.stackpop():
				return False

		start = st.find('<', end+1)
	return stk.isstackempty()

st = input("enter a html tag: ")

if(evalHTML(st)):
	print("matched")
else:
	print("not matched")
