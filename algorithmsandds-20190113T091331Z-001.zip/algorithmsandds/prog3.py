#Modify ArrayStack implementation so that the stack’s capacity is limited to maxlen elements.
# If push is called when the stack is at full capacity, throw a Full exception.
import sys
class limitedStack:
	capacity = 0
	def __init__(self):
		self.data = []
		self.count = 0
	
	def isstackempty(self):
		return self.count == 0
	
	def isstackfull(self):
		return self.count == limitedStack.capacity
	
	def stacklength(self):
		return self.count

	def stackpeek(self):
		if not self.isstackempty():
			return self.data[-1]

	def stackpush(self,ele):
		try:

			if self.count != limitedStack.capacity:  
				self.data.append(ele)
				self.count+=1
			else:
				raise Exception("out of bound")
		except Exception as e:
			print(e)
			sys.exit()
		


	def stackpop(self):
		if not self.isstackempty():
			self.data.pop()
			self.count-=1
	 		
	def displaystack(self):
		print(self.data)

if __name__ == '__main__':
	s1 = limitedStack()
	limitedStack.capacity = int(input("enter stack capacity: "))
	print(limitedStack.capacity)
	print("press '1' to enter elements or '2' to pop elements: ")
	ch = int(input())
	while (ch == 1 or ch == 2):
		

		
		if ch == 1:
			ele = input("enter an element: ")
			s1.stackpush(ele)
			
			
		elif ch == 2:
			s1.stackpop()
			
		
		else:
			print("invalid input")
		s1.displaystack()
		print("press '1' to enter elements or '2' to pop elements:")
		ch = int(input())