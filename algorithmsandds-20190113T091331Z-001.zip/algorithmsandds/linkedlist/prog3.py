##Modify Q1 such that one can add a new element after any specified element.
import LinkedList as l1
class add_element(l1.slist):
	def __init__(self):
		super().__init__()

	def add_e(self,key,val):
		if not self.isEmpty():
			cur = self.head
			new_node = self._Node(val)
		while cur is not None:
			if cur.data == key:
				new_node.next = cur.next
				cur.next = new_node
				return
			cur = cur.next
		return False
if __name__ == '__main__':
	listObj = add_element()
	#listObj.addFirst(10)
	#listObj.addFirst(20)
	#listObj.addFirst(30)
	#listObj.addFirst(40)
	listObj.addLast(10)
	listObj.addLast(20)
	listObj.addLast(40)
	listObj.addLast(200)
	listObj.addAtArbitaryPos(2,25)
	listObj.add_e(20,100)
	listObj.listDisplay()

			

