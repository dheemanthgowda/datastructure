#Add methods to Q1 to find maximum and minimum elements in the list.
import LinkedList as l1

class max_min(l1.slist):
	def __init__(self):
		super().__init__()


	def find_max(self):
		if not self.isEmpty():
			cur = self.head
			m = self.head.data
			while cur is not None:
				if m < cur.data:
					m = cur.data
				cur = cur.next
		return m


	def find_min(self):
		if not self.isEmpty():
			cur = self.head
			m = self.head.data
			while cur is not None:
				if m > cur.data:
					m = cur.data
				cur = cur.next
			return m


if __name__ == '__main__':
	listObj = max_min()
	listObj.addFirst(10)
	#listObj.addFirst(20)
	#listObj.addFirst(30)
	#listObj.addFirst(40)
	listObj.addLast(10)
	listObj.addLast(20)
	listObj.addLast(40)
	listObj.addLast(200)
	listObj.addAtArbitaryPos(2,25)
	#listObj.listDisplay()
	print(listObj.find_min())
	print(listObj.find_max())




