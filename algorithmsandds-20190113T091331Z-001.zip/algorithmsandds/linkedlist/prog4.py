#Modify Q1 such that one can delete any specified element from the list.

class del_element_arb(l1.slist):
	def __init__(self):
		super().__init__()

	def del_ele(self,key):
		if not self.isEmpty():
			cur = self.head
			new_node = self._Node(val)
		while cur is not None:
			if cur.data == key:
				
		 	
			
