#1. Create a single list with methods to add and delete elements from head and tail positions. Provide
#method to check whether an element is present in the list. Count number of elements in the list.
class slist:
	class _Node:
		def __init__(self,ele):
			self.data = ele
			self.next = None
	
	def __init__(self):
			self.head = None
			self.tail = None
			#self.temp = None
			self.count = 0
	def isEmpty(self):
		return self.count == 0
	def addFirst(self,val):
		new_node = self._Node(val)
		if not self.isEmpty():
			new_node.next = self.head
			self.head = new_node
		else:
			self.head = self.tail = new_node
			self.count+=1
	def addLast(self,val):
		new_node = self._Node(val)
		if not self.isEmpty():
			self.tail.next = new_node
			self.tail =	new_node
		else:
			self.head = self.tail = new_node
		self.count+=1
	def delFront(self):
		if not self.isEmpty():
			self.head = self.head.next
			if self.head == None:
				self.tail = None
			self.count -= 1
	def delLast(self):
		if not self.isEmpty():
			if self.head == self.tail:
				self.head = self.tail = None
			else:
				tail = self.tail
				cur = self.head
				while cur.next != tail:
					cur = cur.next
				self.tail = cur
				cur.next = None
			self.count -= 1
	
	def addAtArbitaryPos(self, pos, ele):
		new_node = self._Node(ele)
		#temp = self._Node
		i = 1
		if not self.isEmpty():
			temp = self.head

			while(i < pos and temp!= None):
				#print(temp.data)
				temp = temp.next
				i+=1
			new_node.next = temp.next
			temp.next = new_node	 		

	def listDisplay(self):
		if not self.isEmpty():
			temp = self.head
			while temp != None:
				print(temp.data)
				temp = temp.next

if __name__ == '__main__':
	listObj = slist()
	#listObj.addFirst(10)
	listObj.addFirst(20)
	#listObj.addFirst(30)
	#listObj.addFirst(40)
	listObj.addLast(10)
	listObj.addLast(20)
	listObj.addLast(30)
	listObj.addLast(40)
	#listObj.addAtArbitaryPos(2,25)
	listObj.listDisplay()