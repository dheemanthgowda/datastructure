#Implement a function that reverses a list of elements by pushing them onto a stack in one order, 
#and write them back to the list in reversed order.
import stackmaster
li = [1,2,3,4,5,6]
S = stackmaster.limitedStack()

print("list before pushing them to stack")
print(li)
for ch in li:
		#print(ch)
		S.stackpush(ch)
for ch in range(len(li)):
	li.pop()

def reverselist(S):
	for ch in range(stacklength()):
		li.append(S.stackpop()) 


		
	
reverselist(S)
print("list after reverse",li)

