# Build priority queue to handle real time tasks. Tasks can arrive at time. The attributes of tasks
# are task-id, priority, arrival time, execution time and deadline. Compute waiting time,
# turnaround time for each job. Check whether jobs are completed within the deadline specified.
# It is treated that 10 is maximum priority and 1 is least priority.

44